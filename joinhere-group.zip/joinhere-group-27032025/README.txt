JoinHere · Offline Edition
–––––––––––––––––––––––––––––
Open `index.html` in your browser to begin.

Edit your profile using:
- register.html

Send updates via the register form to upload@joinhere.group if you want to appear in the public version.

Everything is plain HTML. No login, no tracking, no JavaScript required.

You are the user, the host, and the platform.

🧠 joinhere.group


📱 iPhone Warning:
–––––––––––––––––––––––––––––
Offline usage on iPhone is restricted by iOS.
Local HTML files may not display correctly.
For best results, use Android or open via Mac localhost server.


LICENSE
–––––––––––––––––––––––––––––

JoinHere is an open social experiment.

You are free to copy, edit, remix, and share – online or offline.
You don’t need permission to exist.

Please don’t sell this without adding value.
Please don’t lock it behind walls.

© 2025 · Created by joinhere.group · Version 1.0  
A project by celebcare.media, powered by web3.li  
Made with 🍕 by Danyelo Dolce


CHANGELOG – JoinHere Starter Pack
–––––––––––––––––––––––––––––

v1.0 – 2025-03-25
• Erste Veröffentlichung der ZIP-Datei (74 HTML-Seiten, ~21MB)
• Vollständig offline nutzbares Social Network-System
• Enthält alle Kernseiten: Profile, Emoji, Post, Friends, Upload, Download, etc.
• Logo und Footer online verlinkt (voraussichtlich temporär)

📊 Interne Datei-Historie (vor Version 1.0):
• register.html – 47 Versionen (Formularverhalten, Freunde, Emojis, Offline-Modus)
• index.html – 11 Versionen (Zufallsauswahl, Layout, Links)
• emoji-me.html – 7 Versionen (Erklärungen, Auswahl & Klickverhalten)
• send-message.html – 8 Versionen
• send-picture.html – 5 Versionen
• send-post.html – 5 Versionen
• friend-request.html – 4 Versionen
• group-invitation.html – 5 Versionen

---

v1.1 – 2025-03-26
• Veröffentlichung der ZIP-Datei (85 HTML-Seiten, ~11MB)
• Alle Online-Verlinkungen durch lokale Pfade ersetzt
• Logo, Footer & Emojis offlinefähig gemacht
• 404.png komprimiert und verkleinert 
• Formulare angepasst für Offline-Betrieb (keine externe Einbindungen)
• README.txt + LICENSE überarbeitet
• ZIP aktualisiert auf GitHub, Pinata & joinhere.group
• Erste USB-Sticks in Umlauf gebracht – Offline-Release beginnt!

