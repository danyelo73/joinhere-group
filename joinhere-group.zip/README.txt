JoinHere · Offline Edition

Open `index.html` in your browser to begin.

Edit your profile using:
- register.html

Send updates via the register form to upload@joinhere.group if you want to appear in the public version.

Everything is plain HTML. No login, no tracking, no JavaScript required.

You are the user, the host, and the platform.

🧠 joinhere.group


LICENSE
–––––––––––––––––––––––––––––

JoinHere is an open social experiment.

You are free to copy, edit, remix, and share – online or offline.
You don’t need permission to exist.

Please don’t sell this without adding value.
Please don’t lock it behind walls.

© 2025 · Created by joinhere.group · Version 1.0  
A project by celebcare.media, powered by web3.li  
Made with 🍕 by Danyelo Dolce
